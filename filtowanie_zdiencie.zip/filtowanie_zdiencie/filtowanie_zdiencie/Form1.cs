using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;


namespace filtowanie_zdiencie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.Click += button1_Click;
        }
        private void pobieiezToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Pliki obraz�w|*.jpg;*.jpeg;*.png;*.bmp";
                ofd.Title = "Wybierz obrazek";

                // Sprawdzenie, czy u�ytkownik wybra� plik
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Pobranie �cie�ki do wybranego pliku
                        string sciezkaPliku = ofd.FileName;

                        // Za�adowanie obrazu do kontrolki PictureBox
                        pictureBox1.Image = System.Drawing.Image.FromFile(sciezkaPliku);

                        // Opcjonalnie: dostosowanie wy�wietlania obrazu
                        pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                        btnWybierzObraz.Visible = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"B��d podczas �adowania obrazu: {ex.Message}");
                    }
                }
            }

        }

        private void pobieiez2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Pliki obraz�w|*.jpg;*.jpeg;*.png;*.bmp";
                ofd.Title = "Wybierz obrazek";

                // Sprawdzenie, czy u�ytkownik wybra� plik
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Pobranie �cie�ki do wybranego pliku
                        string sciezkaPliku = ofd.FileName;

                        // Za�adowanie obrazu do kontrolki PictureBox
                        pictureBox2.Image = System.Drawing.Image.FromFile(sciezkaPliku);

                        // Opcjonalnie: dostosowanie wy�wietlania obrazu
                        pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
                        btnWybierzObraz2.Visible = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"B��d podczas �adowania obrazu: {ex.Message}");
                    }
                }
            }

        }

        private void btnWybierzObraz_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Pliki obraz�w|*.jpg;*.jpeg;*.png;*.bmp";
                ofd.Title = "Wybierz obrazek";

                // Sprawdzenie, czy u�ytkownik wybra� plik
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Pobranie �cie�ki do wybranego pliku
                        string sciezkaPliku = ofd.FileName;

                        // Za�adowanie obrazu do kontrolki PictureBox
                        pictureBox1.Image = System.Drawing.Image.FromFile(sciezkaPliku);

                        // Opcjonalnie: dostosowanie wy�wietlania obrazu
                        pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                        btnWybierzObraz.Visible = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"B��d podczas �adowania obrazu: {ex.Message}");
                    }
                }
            }
        }
        private void btnWybierzObraz2_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Pliki obraz�w|*.jpg;*.jpeg;*.png;*.bmp";
                ofd.Title = "Wybierz obrazek";

                // Sprawdzenie, czy u�ytkownik wybra� plik
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Pobranie �cie�ki do wybranego pliku
                        string sciezkaPliku = ofd.FileName;

                        // Za�adowanie obrazu do kontrolki PictureBox
                        pictureBox2.Image = System.Drawing.Image.FromFile(sciezkaPliku);

                        // Opcjonalnie: dostosowanie wy�wietlania obrazu
                        pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
                        btnWybierzObraz2.Visible = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"B��d podczas �adowania obrazu: {ex.Message}");
                    }
                }
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("Wczytaj pierwszy obraz.");
                return;
            }

            // Operacje na jednym obrazie
            if (rB_Negatyw.Checked ||
                rB_Przyciemninie.Checked ||
                rB_Rozjasninie.Checked || rB_rozjasnienie.Checked || rB_przyciemnienie.Checked)
            {
                Bitmap obraz = new Bitmap(pictureBox1.Image);
                Bitmap wynik = new Bitmap(obraz.Width, obraz.Height);

                if (rB_Negatyw.Checked)
                    Negatyw(obraz, wynik);

                if (rB_Przyciemninie.Checked)
                    Przyciemnienie(obraz, wynik, trackBar1.Value);

                if (rB_Rozjasninie.Checked)
                    Rozjasnienie(obraz, wynik, trackBar1.Value);
                if (rB_rozjasnienie.Checked)
                {
                    TransformacjaPotegowa(obraz, wynik, 0.5);
                }
                else if (rB_przyciemnienie.Checked)
                {
                    TransformacjaPotegowa(obraz, wynik, 2.0);
                }

                pictureBox3.Image = wynik;
                pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
                return;
            }

            // Operacje na dw�ch obrazach
            if (pictureBox2.Image == null)
            {
                MessageBox.Show("Wczytaj drugi obraz.");
                return;
            }

            Bitmap img1 = new Bitmap(pictureBox1.Image);
            Bitmap img2 = new Bitmap(pictureBox2.Image);

            int width = Math.Min(img1.Width, img2.Width);
            int height = Math.Min(img1.Height, img2.Height);

            Bitmap wynik2 = new Bitmap(width, height);

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color c1 = img1.GetPixel(x, y);
                    Color c2 = img2.GetPixel(x, y);

                    Color nowy = c1;

                    if (rB_Suma.Checked)
                        nowy = BlendSuma(c1, c2);

                    else if (rB_Roznica.Checked)
                        nowy = BlendRoznica(c1, c2);

                    else if (rB_Odejmowanie.Checked)
                        nowy = BlendOdejmowanie(c1, c2);

                    else if (eB_Mnozenie.Checked)
                        nowy = BlendMnozenie(c1, c2);

                    else if (cB_Mnozenie_odwrotno�ci.Checked)
                        nowy = BlendScreen(c1, c2);

                    else if (rB_Ciemniejsze.Checked)
                        nowy = BlendDarken(c1, c2);

                    else if (rB_Ja�niejsze.Checked)
                        nowy = BlendLighten(c1, c2);

                    else if (rB_Wylaczenie.Checked)
                        nowy = BlendExclusion(c1, c2);

                    else if (rB_Negacja.Checked)
                        nowy = BlendNegation(c1, c2);

                    else if (rB_Nakladka.Checked)
                        nowy = BlendOverlay(c1, c2);

                    else if (cB_lagodne_swiatlo.Checked)
                        nowy = BlendSoftLight(c1, c2);

                    else if (rB_Ostre_swiat�o.Checked)
                        nowy = BlendHardLight(c1, c2);

                    else if (rB_Reflect_mode.Checked)
                        nowy = BlendReflect(c1, c2);

                    else if (rB_Wypalanie.Checked)
                        nowy = BlendColorBurn(c1, c2);

                    wynik2.SetPixel(x, y, nowy);
                }
            }

            pictureBox3.Image = wynik2;
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
        }


        private void Negatyw(Bitmap obraz, Bitmap wynik)
        {
            for (int y = 0; y < obraz.Height; y++)
            {
                for (int x = 0; x < obraz.Width; x++)
                {
                    Color p = obraz.GetPixel(x, y);

                    wynik.SetPixel(x, y,
                        Color.FromArgb(
                            255 - p.R,
                            255 - p.G,
                            255 - p.B));
                }
            }
        }
        private void Rozjasnienie(Bitmap obraz, Bitmap wynik, int wartosc)
        {
            for (int y = 0; y < obraz.Height; y++)
            {
                for (int x = 0; x < obraz.Width; x++)
                {
                    Color p = obraz.GetPixel(x, y);

                    int r = Math.Min(255, p.R + wartosc);
                    int g = Math.Min(255, p.G + wartosc);
                    int b = Math.Min(255, p.B + wartosc);

                    wynik.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
        }
        private void Przyciemnienie(Bitmap obraz, Bitmap wynik, int wartosc)
        {
            for (int y = 0; y < obraz.Height; y++)
            {
                for (int x = 0; x < obraz.Width; x++)
                {
                    Color p = obraz.GetPixel(x, y);

                    int r = Math.Max(0, p.R - wartosc);
                    int g = Math.Max(0, p.G - wartosc);
                    int b = Math.Max(0, p.B - wartosc);

                    wynik.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
        }
        private void TransformacjaPotegowa(Bitmap obraz, Bitmap wynik, double gamma)
        {
            for (int y = 0; y < obraz.Height; y++)
            {
                for (int x = 0; x < obraz.Width; x++)
                {
                    Color p = obraz.GetPixel(x, y);

                    int r = (int)(255 * Math.Pow(p.R / 255.0, gamma));
                    int g = (int)(255 * Math.Pow(p.G / 255.0, gamma));
                    int b = (int)(255 * Math.Pow(p.B / 255.0, gamma));

                    r = Math.Max(0, Math.Min(255, r));
                    g = Math.Max(0, Math.Min(255, g));
                    b = Math.Max(0, Math.Min(255, b));

                    wynik.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
        }

        private int Clamp(int v)
        {
            return Math.Max(0, Math.Min(255, v));
        }
        private Color BlendSuma(Color a, Color b)
        {
            return Color.FromArgb(
                Clamp(a.R + b.R),
                Clamp(a.G + b.G),
                Clamp(a.B + b.B));
        }
        private Color BlendRoznica(Color a, Color b)
        {
            return Color.FromArgb(
                Math.Abs(a.R - b.R),
                Math.Abs(a.G - b.G),
                Math.Abs(a.B - b.B));
        }
        private Color BlendOdejmowanie(Color a, Color b)
        {
            return Color.FromArgb(
                Clamp(a.R - b.R),
                Clamp(a.G - b.G),
                Clamp(a.B - b.B));
        }

        private Color BlendMnozenie(Color a, Color b)
        {
            return Color.FromArgb(
                a.R * b.R / 255,
                a.G * b.G / 255,
                a.B * b.B / 255);
        }
        private Color BlendScreen(Color a, Color b)
        {
            return Color.FromArgb(
                255 - ((255 - a.R) * (255 - b.R) / 255),
                255 - ((255 - a.G) * (255 - b.G) / 255),
                255 - ((255 - a.B) * (255 - b.B) / 255));
        }
        private Color BlendDarken(Color a, Color b)
        {
            return Color.FromArgb(
                Math.Min(a.R, b.R),
                Math.Min(a.G, b.G),
                Math.Min(a.B, b.B));
        }
        private Color BlendLighten(Color a, Color b)
        {
            return Color.FromArgb(
                Math.Max(a.R, b.R),
                Math.Max(a.G, b.G),
                Math.Max(a.B, b.B));
        }
        private Color BlendExclusion(Color a, Color b)
        {
            return Color.FromArgb(
                Clamp(a.R + b.R - 2 * a.R * b.R / 255),
                Clamp(a.G + b.G - 2 * a.G * b.G / 255),
                Clamp(a.B + b.B - 2 * a.B * b.B / 255));
        }
        private Color BlendNegation(Color a, Color b)
        {
            return Color.FromArgb(
                255 - Math.Abs(255 - a.R - b.R),
                255 - Math.Abs(255 - a.G - b.G),
                255 - Math.Abs(255 - a.B - b.B));
        }
        private int Overlay(int a, int b)
        {
            return a < 128
                ? (2 * a * b / 255)
                : (255 - 2 * (255 - a) * (255 - b) / 255);
        }

        private Color BlendOverlay(Color a, Color b)
        {
            return Color.FromArgb(
                Overlay(a.R, b.R),
                Overlay(a.G, b.G),
                Overlay(a.B, b.B));
        }
        private Color BlendSoftLight(Color a, Color b)
        {
            return Color.FromArgb(
                (a.R * (255 - b.R) + 2 * b.R * a.R) / 255,
                (a.G * (255 - b.G) + 2 * b.G * a.G) / 255,
                (a.B * (255 - b.B) + 2 * b.B * a.B) / 255);
        }
        private Color BlendHardLight(Color a, Color b)
        {
            return Color.FromArgb(
                Overlay(b.R, a.R),
                Overlay(b.G, a.G),
                Overlay(b.B, a.B));
        }
        private int Reflect(int a, int b)
        {
            if (b == 255)
                return 255;

            return Clamp(a * a / (255 - b));
        }

        private Color BlendReflect(Color a, Color b)
        {
            return Color.FromArgb(
                Reflect(a.R, b.R),
                Reflect(a.G, b.G),
                Reflect(a.B, b.B));
        }
        private int Burn(int a, int b)
        {
            if (b == 0)
                return 0;

            return Clamp(255 - ((255 - a) * 255 / b));
        }

        private Color BlendColorBurn(Color a, Color b)
        {
            return Color.FromArgb(
                Burn(a.R, b.R),
                Burn(a.G, b.G),
                Burn(a.B, b.B));
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            int aktualnaWartosc = trackBar1.Value;
            label1.Text = aktualnaWartosc.ToString();
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {

        }

        /*double gamma = trackBar1.Value / 100.0;

       if (gamma < 0.1)
       gamma = 0.1;*/
    }
}













