﻿namespace filtowanie_zdiencie
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            noweToolStripMenuItem = new ToolStripMenuItem();
            otwórzToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator = new ToolStripSeparator();
            zapiszToolStripMenuItem = new ToolStripMenuItem();
            zapiszAsToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            printToolStripMenuItem = new ToolStripMenuItem();
            podglądwydrukuToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator2 = new ToolStripSeparator();
            zakończToolStripMenuItem = new ToolStripMenuItem();
            edytujToolStripMenuItem = new ToolStripMenuItem();
            cofnijToolStripMenuItem = new ToolStripMenuItem();
            redoToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator3 = new ToolStripSeparator();
            wytnijToolStripMenuItem = new ToolStripMenuItem();
            copyToolStripMenuItem = new ToolStripMenuItem();
            pasteToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator4 = new ToolStripSeparator();
            wybierzwszystkoToolStripMenuItem = new ToolStripMenuItem();
            narzędziaToolStripMenuItem = new ToolStripMenuItem();
            customizeToolStripMenuItem = new ToolStripMenuItem();
            optionsToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            zawartośćToolStripMenuItem = new ToolStripMenuItem();
            indexToolStripMenuItem = new ToolStripMenuItem();
            wyszukajToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator5 = new ToolStripSeparator();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            pobiezzdiecieToolStripMenuItem = new ToolStripMenuItem();
            pobieiezToolStripMenuItem = new ToolStripMenuItem();
            pobieiez2ToolStripMenuItem = new ToolStripMenuItem();
            gB_filcy_obrzu = new GroupBox();
            button1 = new Button();
            panel1 = new Panel();
            l_wattoc_pissil = new Label();
            label4 = new Label();
            trackBar1 = new TrackBar();
            rB_Wypalanie = new RadioButton();
            rB_Przezroczystosc = new RadioButton();
            cB_lagodne_swiatlo = new RadioButton();
            rB_Nakladka = new RadioButton();
            rB_Jaśniejsze = new RadioButton();
            rB_Negacja = new RadioButton();
            eB_Mnozenie = new RadioButton();
            rB_Odejmowanie = new RadioButton();
            rB_Rozcienczenie = new RadioButton();
            rB_Reflect_mode = new RadioButton();
            rB_Ostre_swiatło = new RadioButton();
            rB_Wylaczenie = new RadioButton();
            rB_Ciemniejsze = new RadioButton();
            cB_Mnozenie_odwrotności = new RadioButton();
            rB_Roznica = new RadioButton();
            rB_Suma = new RadioButton();
            rB_przyciemnienie = new RadioButton();
            rB_rozjasnienie = new RadioButton();
            label3 = new Label();
            label2 = new Label();
            rB_Rozjasninie = new RadioButton();
            rB_Przyciemninie = new RadioButton();
            rB_Negatyw = new RadioButton();
            label1 = new Label();
            btnWybierzObraz = new Button();
            pictureBox1 = new PictureBox();
            openFileDialog1 = new OpenFileDialog();
            saveFileDialog1 = new SaveFileDialog();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            btnWybierzObraz2 = new Button();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            l_wattoc_pissil2 = new Label();
            label6 = new Label();
            trackBar2 = new TrackBar();
            menuStrip1.SuspendLayout();
            gB_filcy_obrzu.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, edytujToolStripMenuItem, narzędziaToolStripMenuItem, helpToolStripMenuItem, pobiezzdiecieToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(951, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { noweToolStripMenuItem, otwórzToolStripMenuItem, toolStripSeparator, zapiszToolStripMenuItem, zapiszAsToolStripMenuItem, toolStripSeparator1, printToolStripMenuItem, podglądwydrukuToolStripMenuItem, toolStripSeparator2, zakończToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "&File";
            // 
            // noweToolStripMenuItem
            // 
            noweToolStripMenuItem.Image = (Image)resources.GetObject("noweToolStripMenuItem.Image");
            noweToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            noweToolStripMenuItem.Name = "noweToolStripMenuItem";
            noweToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.N;
            noweToolStripMenuItem.Size = new Size(167, 22);
            noweToolStripMenuItem.Text = "&Nowe";
            // 
            // otwórzToolStripMenuItem
            // 
            otwórzToolStripMenuItem.Image = (Image)resources.GetObject("otwórzToolStripMenuItem.Image");
            otwórzToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            otwórzToolStripMenuItem.Name = "otwórzToolStripMenuItem";
            otwórzToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.O;
            otwórzToolStripMenuItem.Size = new Size(167, 22);
            otwórzToolStripMenuItem.Text = "&Otwórz";
            // 
            // toolStripSeparator
            // 
            toolStripSeparator.Name = "toolStripSeparator";
            toolStripSeparator.Size = new Size(164, 6);
            // 
            // zapiszToolStripMenuItem
            // 
            zapiszToolStripMenuItem.Image = (Image)resources.GetObject("zapiszToolStripMenuItem.Image");
            zapiszToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            zapiszToolStripMenuItem.Name = "zapiszToolStripMenuItem";
            zapiszToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.S;
            zapiszToolStripMenuItem.Size = new Size(167, 22);
            zapiszToolStripMenuItem.Text = "&Zapisz";
            // 
            // zapiszAsToolStripMenuItem
            // 
            zapiszAsToolStripMenuItem.Name = "zapiszAsToolStripMenuItem";
            zapiszAsToolStripMenuItem.Size = new Size(167, 22);
            zapiszAsToolStripMenuItem.Text = "Zapisz &As";
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(164, 6);
            // 
            // printToolStripMenuItem
            // 
            printToolStripMenuItem.Image = (Image)resources.GetObject("printToolStripMenuItem.Image");
            printToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            printToolStripMenuItem.Name = "printToolStripMenuItem";
            printToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.P;
            printToolStripMenuItem.Size = new Size(167, 22);
            printToolStripMenuItem.Text = "&Print";
            // 
            // podglądwydrukuToolStripMenuItem
            // 
            podglądwydrukuToolStripMenuItem.Image = (Image)resources.GetObject("podglądwydrukuToolStripMenuItem.Image");
            podglądwydrukuToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            podglądwydrukuToolStripMenuItem.Name = "podglądwydrukuToolStripMenuItem";
            podglądwydrukuToolStripMenuItem.Size = new Size(167, 22);
            podglądwydrukuToolStripMenuItem.Text = "&Podgląd wydruku";
            // 
            // toolStripSeparator2
            // 
            toolStripSeparator2.Name = "toolStripSeparator2";
            toolStripSeparator2.Size = new Size(164, 6);
            // 
            // zakończToolStripMenuItem
            // 
            zakończToolStripMenuItem.Name = "zakończToolStripMenuItem";
            zakończToolStripMenuItem.Size = new Size(167, 22);
            zakończToolStripMenuItem.Text = "&Zakończ";
            // 
            // edytujToolStripMenuItem
            // 
            edytujToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cofnijToolStripMenuItem, redoToolStripMenuItem, toolStripSeparator3, wytnijToolStripMenuItem, copyToolStripMenuItem, pasteToolStripMenuItem, toolStripSeparator4, wybierzwszystkoToolStripMenuItem });
            edytujToolStripMenuItem.Name = "edytujToolStripMenuItem";
            edytujToolStripMenuItem.Size = new Size(52, 20);
            edytujToolStripMenuItem.Text = "&Edytuj";
            // 
            // cofnijToolStripMenuItem
            // 
            cofnijToolStripMenuItem.Name = "cofnijToolStripMenuItem";
            cofnijToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.Z;
            cofnijToolStripMenuItem.Size = new Size(166, 22);
            cofnijToolStripMenuItem.Text = "&Cofnij";
            // 
            // redoToolStripMenuItem
            // 
            redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            redoToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.Y;
            redoToolStripMenuItem.Size = new Size(166, 22);
            redoToolStripMenuItem.Text = "&Redo";
            // 
            // toolStripSeparator3
            // 
            toolStripSeparator3.Name = "toolStripSeparator3";
            toolStripSeparator3.Size = new Size(163, 6);
            // 
            // wytnijToolStripMenuItem
            // 
            wytnijToolStripMenuItem.Image = (Image)resources.GetObject("wytnijToolStripMenuItem.Image");
            wytnijToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            wytnijToolStripMenuItem.Name = "wytnijToolStripMenuItem";
            wytnijToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.X;
            wytnijToolStripMenuItem.Size = new Size(166, 22);
            wytnijToolStripMenuItem.Text = "Wyt&nij";
            // 
            // copyToolStripMenuItem
            // 
            copyToolStripMenuItem.Image = (Image)resources.GetObject("copyToolStripMenuItem.Image");
            copyToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            copyToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.C;
            copyToolStripMenuItem.Size = new Size(166, 22);
            copyToolStripMenuItem.Text = "&Copy";
            // 
            // pasteToolStripMenuItem
            // 
            pasteToolStripMenuItem.Image = (Image)resources.GetObject("pasteToolStripMenuItem.Image");
            pasteToolStripMenuItem.ImageTransparentColor = Color.Magenta;
            pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            pasteToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.V;
            pasteToolStripMenuItem.Size = new Size(166, 22);
            pasteToolStripMenuItem.Text = "&Paste";
            // 
            // toolStripSeparator4
            // 
            toolStripSeparator4.Name = "toolStripSeparator4";
            toolStripSeparator4.Size = new Size(163, 6);
            // 
            // wybierzwszystkoToolStripMenuItem
            // 
            wybierzwszystkoToolStripMenuItem.Name = "wybierzwszystkoToolStripMenuItem";
            wybierzwszystkoToolStripMenuItem.Size = new Size(166, 22);
            wybierzwszystkoToolStripMenuItem.Text = "Wybier&z wszystko";
            // 
            // narzędziaToolStripMenuItem
            // 
            narzędziaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { customizeToolStripMenuItem, optionsToolStripMenuItem });
            narzędziaToolStripMenuItem.Name = "narzędziaToolStripMenuItem";
            narzędziaToolStripMenuItem.Size = new Size(70, 20);
            narzędziaToolStripMenuItem.Text = "&Narzędzia";
            // 
            // customizeToolStripMenuItem
            // 
            customizeToolStripMenuItem.Name = "customizeToolStripMenuItem";
            customizeToolStripMenuItem.Size = new Size(130, 22);
            customizeToolStripMenuItem.Text = "&Customize";
            // 
            // optionsToolStripMenuItem
            // 
            optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            optionsToolStripMenuItem.Size = new Size(130, 22);
            optionsToolStripMenuItem.Text = "&Options";
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { zawartośćToolStripMenuItem, indexToolStripMenuItem, wyszukajToolStripMenuItem, toolStripSeparator5, aboutToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "&Help";
            // 
            // zawartośćToolStripMenuItem
            // 
            zawartośćToolStripMenuItem.Name = "zawartośćToolStripMenuItem";
            zawartośćToolStripMenuItem.Size = new Size(128, 22);
            zawartośćToolStripMenuItem.Text = "&Zawartość";
            // 
            // indexToolStripMenuItem
            // 
            indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            indexToolStripMenuItem.Size = new Size(128, 22);
            indexToolStripMenuItem.Text = "&Index";
            // 
            // wyszukajToolStripMenuItem
            // 
            wyszukajToolStripMenuItem.Name = "wyszukajToolStripMenuItem";
            wyszukajToolStripMenuItem.Size = new Size(128, 22);
            wyszukajToolStripMenuItem.Text = "&Wyszukaj";
            // 
            // toolStripSeparator5
            // 
            toolStripSeparator5.Name = "toolStripSeparator5";
            toolStripSeparator5.Size = new Size(125, 6);
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(128, 22);
            aboutToolStripMenuItem.Text = "&About...";
            // 
            // pobiezzdiecieToolStripMenuItem
            // 
            pobiezzdiecieToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { pobieiezToolStripMenuItem, pobieiez2ToolStripMenuItem });
            pobiezzdiecieToolStripMenuItem.Name = "pobiezzdiecieToolStripMenuItem";
            pobiezzdiecieToolStripMenuItem.Size = new Size(96, 20);
            pobiezzdiecieToolStripMenuItem.Text = "import_zdiecie";
            // 
            // pobieiezToolStripMenuItem
            // 
            pobieiezToolStripMenuItem.Name = "pobieiezToolStripMenuItem";
            pobieiezToolStripMenuItem.Size = new Size(129, 22);
            pobieiezToolStripMenuItem.Text = "pobieiez_1";
            pobieiezToolStripMenuItem.Click += pobieiezToolStripMenuItem_Click;
            // 
            // pobieiez2ToolStripMenuItem
            // 
            pobieiez2ToolStripMenuItem.Name = "pobieiez2ToolStripMenuItem";
            pobieiez2ToolStripMenuItem.Size = new Size(129, 22);
            pobieiez2ToolStripMenuItem.Text = "pobieiez_2";
            pobieiez2ToolStripMenuItem.Click += pobieiez2ToolStripMenuItem_Click;
            // 
            // gB_filcy_obrzu
            // 
            gB_filcy_obrzu.Controls.Add(button1);
            gB_filcy_obrzu.Controls.Add(panel1);
            gB_filcy_obrzu.Controls.Add(rB_Wypalanie);
            gB_filcy_obrzu.Controls.Add(rB_Przezroczystosc);
            gB_filcy_obrzu.Controls.Add(cB_lagodne_swiatlo);
            gB_filcy_obrzu.Controls.Add(rB_Nakladka);
            gB_filcy_obrzu.Controls.Add(rB_Jaśniejsze);
            gB_filcy_obrzu.Controls.Add(rB_Negacja);
            gB_filcy_obrzu.Controls.Add(eB_Mnozenie);
            gB_filcy_obrzu.Controls.Add(rB_Odejmowanie);
            gB_filcy_obrzu.Controls.Add(rB_Rozcienczenie);
            gB_filcy_obrzu.Controls.Add(rB_Reflect_mode);
            gB_filcy_obrzu.Controls.Add(rB_Ostre_swiatło);
            gB_filcy_obrzu.Controls.Add(rB_Wylaczenie);
            gB_filcy_obrzu.Controls.Add(rB_Ciemniejsze);
            gB_filcy_obrzu.Controls.Add(cB_Mnozenie_odwrotności);
            gB_filcy_obrzu.Controls.Add(rB_Roznica);
            gB_filcy_obrzu.Controls.Add(rB_Suma);
            gB_filcy_obrzu.Controls.Add(rB_przyciemnienie);
            gB_filcy_obrzu.Controls.Add(rB_rozjasnienie);
            gB_filcy_obrzu.Controls.Add(label3);
            gB_filcy_obrzu.Controls.Add(label2);
            gB_filcy_obrzu.Controls.Add(rB_Rozjasninie);
            gB_filcy_obrzu.Controls.Add(rB_Przyciemninie);
            gB_filcy_obrzu.Controls.Add(rB_Negatyw);
            gB_filcy_obrzu.Controls.Add(label1);
            gB_filcy_obrzu.Location = new Point(12, 27);
            gB_filcy_obrzu.Name = "gB_filcy_obrzu";
            gB_filcy_obrzu.Size = new Size(268, 506);
            gB_filcy_obrzu.TabIndex = 1;
            gB_filcy_obrzu.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(42, 477);
            button1.Name = "button1";
            button1.Size = new Size(151, 23);
            button1.TabIndex = 26;
            button1.Text = "wykonaj trformacie";
            button1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.Controls.Add(l_wattoc_pissil2);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(trackBar2);
            panel1.Controls.Add(l_wattoc_pissil);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(trackBar1);
            panel1.Location = new Point(6, 330);
            panel1.Name = "panel1";
            panel1.Size = new Size(247, 150);
            panel1.TabIndex = 25;
            // 
            // l_wattoc_pissil
            // 
            l_wattoc_pissil.AutoSize = true;
            l_wattoc_pissil.Location = new Point(188, 38);
            l_wattoc_pissil.Name = "l_wattoc_pissil";
            l_wattoc_pissil.Size = new Size(13, 15);
            l_wattoc_pissil.TabIndex = 6;
            l_wattoc_pissil.Text = "0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 10);
            label4.Name = "label4";
            label4.Size = new Size(196, 15);
            label4.TabIndex = 5;
            label4.Text = "wart dla pixli w zakresie od 0 do 255:";
            // 
            // trackBar1
            // 
            trackBar1.Location = new Point(9, 28);
            trackBar1.Maximum = 255;
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(162, 45);
            trackBar1.TabIndex = 4;
            trackBar1.ValueChanged += trackBar1_ValueChanged;
            // 
            // rB_Wypalanie
            // 
            rB_Wypalanie.AutoSize = true;
            rB_Wypalanie.Location = new Point(153, 280);
            rB_Wypalanie.Name = "rB_Wypalanie";
            rB_Wypalanie.Size = new Size(83, 19);
            rB_Wypalanie.TabIndex = 24;
            rB_Wypalanie.TabStop = true;
            rB_Wypalanie.Text = " Wypalanie";
            rB_Wypalanie.UseVisualStyleBackColor = true;
            // 
            // rB_Przezroczystosc
            // 
            rB_Przezroczystosc.AutoSize = true;
            rB_Przezroczystosc.Location = new Point(153, 305);
            rB_Przezroczystosc.Name = "rB_Przezroczystosc";
            rB_Przezroczystosc.Size = new Size(107, 19);
            rB_Przezroczystosc.TabIndex = 23;
            rB_Przezroczystosc.TabStop = true;
            rB_Przezroczystosc.Text = "Przezroczystość";
            rB_Przezroczystosc.UseVisualStyleBackColor = true;
            // 
            // cB_lagodne_swiatlo
            // 
            cB_lagodne_swiatlo.AutoSize = true;
            cB_lagodne_swiatlo.Location = new Point(153, 255);
            cB_lagodne_swiatlo.Name = "cB_lagodne_swiatlo";
            cB_lagodne_swiatlo.Size = new Size(114, 19);
            cB_lagodne_swiatlo.TabIndex = 22;
            cB_lagodne_swiatlo.TabStop = true;
            cB_lagodne_swiatlo.Text = " Łagodne światło";
            cB_lagodne_swiatlo.UseVisualStyleBackColor = true;
            // 
            // rB_Nakladka
            // 
            rB_Nakladka.AutoSize = true;
            rB_Nakladka.Location = new Point(154, 230);
            rB_Nakladka.Name = "rB_Nakladka";
            rB_Nakladka.Size = new Size(74, 19);
            rB_Nakladka.TabIndex = 21;
            rB_Nakladka.TabStop = true;
            rB_Nakladka.Text = "Nakładka";
            rB_Nakladka.UseVisualStyleBackColor = true;
            // 
            // rB_Jaśniejsze
            // 
            rB_Jaśniejsze.AutoSize = true;
            rB_Jaśniejsze.Location = new Point(154, 205);
            rB_Jaśniejsze.Name = "rB_Jaśniejsze";
            rB_Jaśniejsze.Size = new Size(75, 19);
            rB_Jaśniejsze.TabIndex = 20;
            rB_Jaśniejsze.TabStop = true;
            rB_Jaśniejsze.Text = "Jaśniejsze";
            rB_Jaśniejsze.UseVisualStyleBackColor = true;
            // 
            // rB_Negacja
            // 
            rB_Negacja.AutoSize = true;
            rB_Negacja.Location = new Point(154, 177);
            rB_Negacja.Name = "rB_Negacja";
            rB_Negacja.Size = new Size(68, 19);
            rB_Negacja.TabIndex = 19;
            rB_Negacja.TabStop = true;
            rB_Negacja.Text = "Negacja";
            rB_Negacja.UseVisualStyleBackColor = true;
            // 
            // eB_Mnozenie
            // 
            eB_Mnozenie.AutoSize = true;
            eB_Mnozenie.Location = new Point(154, 155);
            eB_Mnozenie.Name = "eB_Mnozenie";
            eB_Mnozenie.Size = new Size(77, 19);
            eB_Mnozenie.TabIndex = 18;
            eB_Mnozenie.TabStop = true;
            eB_Mnozenie.Text = "Mnożenie";
            eB_Mnozenie.UseVisualStyleBackColor = true;
            // 
            // rB_Odejmowanie
            // 
            rB_Odejmowanie.AutoSize = true;
            rB_Odejmowanie.Location = new Point(154, 130);
            rB_Odejmowanie.Name = "rB_Odejmowanie";
            rB_Odejmowanie.Size = new Size(99, 19);
            rB_Odejmowanie.TabIndex = 17;
            rB_Odejmowanie.TabStop = true;
            rB_Odejmowanie.Text = "Odejmowanie";
            rB_Odejmowanie.UseVisualStyleBackColor = true;
            // 
            // rB_Rozcienczenie
            // 
            rB_Rozcienczenie.AutoSize = true;
            rB_Rozcienczenie.Location = new Point(6, 280);
            rB_Rozcienczenie.Name = "rB_Rozcienczenie";
            rB_Rozcienczenie.Size = new Size(99, 19);
            rB_Rozcienczenie.TabIndex = 16;
            rB_Rozcienczenie.TabStop = true;
            rB_Rozcienczenie.Text = "Rozcieńczenie";
            rB_Rozcienczenie.UseVisualStyleBackColor = true;
            // 
            // rB_Reflect_mode
            // 
            rB_Reflect_mode.AutoSize = true;
            rB_Reflect_mode.Location = new Point(6, 305);
            rB_Reflect_mode.Name = "rB_Reflect_mode";
            rB_Reflect_mode.Size = new Size(95, 19);
            rB_Reflect_mode.TabIndex = 15;
            rB_Reflect_mode.TabStop = true;
            rB_Reflect_mode.Text = "Reflect mode";
            rB_Reflect_mode.UseVisualStyleBackColor = true;
            // 
            // rB_Ostre_swiatło
            // 
            rB_Ostre_swiatło.AutoSize = true;
            rB_Ostre_swiatło.Location = new Point(6, 255);
            rB_Ostre_swiatło.Name = "rB_Ostre_swiatło";
            rB_Ostre_swiatło.Size = new Size(93, 19);
            rB_Ostre_swiatło.TabIndex = 14;
            rB_Ostre_swiatło.TabStop = true;
            rB_Ostre_swiatło.Text = "Ostre światło";
            rB_Ostre_swiatło.UseVisualStyleBackColor = true;
            // 
            // rB_Wylaczenie
            // 
            rB_Wylaczenie.AutoSize = true;
            rB_Wylaczenie.Location = new Point(7, 230);
            rB_Wylaczenie.Name = "rB_Wylaczenie";
            rB_Wylaczenie.Size = new Size(84, 19);
            rB_Wylaczenie.TabIndex = 13;
            rB_Wylaczenie.TabStop = true;
            rB_Wylaczenie.Text = "Wyłączenie";
            rB_Wylaczenie.UseVisualStyleBackColor = true;
            // 
            // rB_Ciemniejsze
            // 
            rB_Ciemniejsze.AutoSize = true;
            rB_Ciemniejsze.Location = new Point(7, 205);
            rB_Ciemniejsze.Name = "rB_Ciemniejsze";
            rB_Ciemniejsze.Size = new Size(88, 19);
            rB_Ciemniejsze.TabIndex = 12;
            rB_Ciemniejsze.TabStop = true;
            rB_Ciemniejsze.Text = "Ciemniejsze";
            rB_Ciemniejsze.UseVisualStyleBackColor = true;
            // 
            // cB_Mnozenie_odwrotności
            // 
            cB_Mnozenie_odwrotności.AutoSize = true;
            cB_Mnozenie_odwrotności.Location = new Point(6, 177);
            cB_Mnozenie_odwrotności.Name = "cB_Mnozenie_odwrotności";
            cB_Mnozenie_odwrotności.Size = new Size(146, 19);
            cB_Mnozenie_odwrotności.TabIndex = 11;
            cB_Mnozenie_odwrotności.TabStop = true;
            cB_Mnozenie_odwrotności.Text = "Mnożenie odwrotności";
            cB_Mnozenie_odwrotności.UseVisualStyleBackColor = true;
            // 
            // rB_Roznica
            // 
            rB_Roznica.AutoSize = true;
            rB_Roznica.Location = new Point(7, 155);
            rB_Roznica.Name = "rB_Roznica";
            rB_Roznica.Size = new Size(66, 19);
            rB_Roznica.TabIndex = 10;
            rB_Roznica.TabStop = true;
            rB_Roznica.Text = "Różnica";
            rB_Roznica.UseVisualStyleBackColor = true;
            // 
            // rB_Suma
            // 
            rB_Suma.AutoSize = true;
            rB_Suma.Location = new Point(7, 130);
            rB_Suma.Name = "rB_Suma";
            rB_Suma.Size = new Size(55, 19);
            rB_Suma.TabIndex = 9;
            rB_Suma.TabStop = true;
            rB_Suma.Text = "Suma";
            rB_Suma.UseVisualStyleBackColor = true;
            // 
            // rB_przyciemnienie
            // 
            rB_przyciemnienie.AutoSize = true;
            rB_przyciemnienie.Location = new Point(94, 90);
            rB_przyciemnienie.Name = "rB_przyciemnienie";
            rB_przyciemnienie.Size = new Size(105, 19);
            rB_przyciemnienie.TabIndex = 8;
            rB_przyciemnienie.TabStop = true;
            rB_przyciemnienie.Text = "przyciemnienie";
            rB_przyciemnienie.UseVisualStyleBackColor = true;
            // 
            // rB_rozjasnienie
            // 
            rB_rozjasnienie.AutoSize = true;
            rB_rozjasnienie.Location = new Point(6, 90);
            rB_rozjasnienie.Name = "rB_rozjasnienie";
            rB_rozjasnienie.Size = new Size(87, 19);
            rB_rozjasnienie.TabIndex = 7;
            rB_rozjasnienie.TabStop = true;
            rB_rozjasnienie.Text = "rozjaśnienie";
            rB_rozjasnienie.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(2, 112);
            label3.Name = "label3";
            label3.Size = new Size(146, 15);
            label3.TabIndex = 6;
            label3.Text = "Mieszanie dwóch obrazów";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(0, 72);
            label2.Name = "label2";
            label2.Size = new Size(138, 15);
            label2.TabIndex = 5;
            label2.Text = "Transformacje potęgowe";
            // 
            // rB_Rozjasninie
            // 
            rB_Rozjasninie.AutoSize = true;
            rB_Rozjasninie.Location = new Point(109, 50);
            rB_Rozjasninie.Name = "rB_Rozjasninie";
            rB_Rozjasninie.Size = new Size(84, 19);
            rB_Rozjasninie.TabIndex = 3;
            rB_Rozjasninie.TabStop = true;
            rB_Rozjasninie.Text = "Rozjaśninie";
            rB_Rozjasninie.UseVisualStyleBackColor = true;
            // 
            // rB_Przyciemninie
            // 
            rB_Przyciemninie.AutoSize = true;
            rB_Przyciemninie.Location = new Point(7, 50);
            rB_Przyciemninie.Name = "rB_Przyciemninie";
            rB_Przyciemninie.Size = new Size(99, 19);
            rB_Przyciemninie.TabIndex = 2;
            rB_Przyciemninie.TabStop = true;
            rB_Przyciemninie.Text = "Przyciemninie";
            rB_Przyciemninie.UseVisualStyleBackColor = true;
            // 
            // rB_Negatyw
            // 
            rB_Negatyw.AutoSize = true;
            rB_Negatyw.Location = new Point(7, 27);
            rB_Negatyw.Name = "rB_Negatyw";
            rB_Negatyw.Size = new Size(72, 19);
            rB_Negatyw.TabIndex = 1;
            rB_Negatyw.TabStop = true;
            rB_Negatyw.Text = "Negatyw";
            rB_Negatyw.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 9);
            label1.Name = "label1";
            label1.Size = new Size(123, 15);
            label1.TabIndex = 0;
            label1.Text = "Transformacje liniowe";
            // 
            // btnWybierzObraz
            // 
            btnWybierzObraz.Location = new Point(370, 99);
            btnWybierzObraz.Name = "btnWybierzObraz";
            btnWybierzObraz.Size = new Size(135, 23);
            btnWybierzObraz.TabIndex = 3;
            btnWybierzObraz.Text = "wubiez zdiecie";
            btnWybierzObraz.UseVisualStyleBackColor = true;
            btnWybierzObraz.Click += btnWybierzObraz_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(312, 54);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(260, 144);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnWybierzObraz2
            // 
            btnWybierzObraz2.Location = new Point(646, 113);
            btnWybierzObraz2.Name = "btnWybierzObraz2";
            btnWybierzObraz2.Size = new Size(135, 23);
            btnWybierzObraz2.TabIndex = 5;
            btnWybierzObraz2.Text = "wubiez zdiecie";
            btnWybierzObraz2.UseVisualStyleBackColor = true;
            btnWybierzObraz2.Click += btnWybierzObraz2_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(581, 54);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(260, 144);
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(312, 204);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(529, 290);
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            // 
            // l_wattoc_pissil2
            // 
            l_wattoc_pissil2.AutoSize = true;
            l_wattoc_pissil2.Location = new Point(199, 86);
            l_wattoc_pissil2.Name = "l_wattoc_pissil2";
            l_wattoc_pissil2.Size = new Size(13, 15);
            l_wattoc_pissil2.TabIndex = 9;
            l_wattoc_pissil2.Text = "0";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(20, 58);
            label6.Name = "label6";
            label6.Size = new Size(196, 15);
            label6.TabIndex = 8;
            label6.Text = "wart dla pixli w zakresie od 0 do 255:";
            // 
            // trackBar2
            // 
            trackBar2.Location = new Point(20, 76);
            trackBar2.Maximum = 255;
            trackBar2.Name = "trackBar2";
            trackBar2.Size = new Size(162, 45);
            trackBar2.TabIndex = 7;
            trackBar2.Scroll += trackBar2_Scroll;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(951, 545);
            Controls.Add(pictureBox3);
            Controls.Add(btnWybierzObraz2);
            Controls.Add(pictureBox2);
            Controls.Add(btnWybierzObraz);
            Controls.Add(pictureBox1);
            Controls.Add(gB_filcy_obrzu);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            gB_filcy_obrzu.ResumeLayout(false);
            gB_filcy_obrzu.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBar2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private GroupBox gB_filcy_obrzu;
        private Label label1;
        private RadioButton rB_Rozjasninie;
        private RadioButton rB_Przyciemninie;
        private RadioButton rB_Negatyw;
        private TrackBar trackBar1;
        private PictureBox pictureBox1;
        private Button btnWybierzObraz;
        private OpenFileDialog openFileDialog1;
        private SaveFileDialog saveFileDialog1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem noweToolStripMenuItem;
        private ToolStripMenuItem otwórzToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator;
        private ToolStripMenuItem zapiszToolStripMenuItem;
        private ToolStripMenuItem zapiszAsToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem printToolStripMenuItem;
        private ToolStripMenuItem podglądwydrukuToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem zakończToolStripMenuItem;
        private ToolStripMenuItem edytujToolStripMenuItem;
        private ToolStripMenuItem cofnijToolStripMenuItem;
        private ToolStripMenuItem redoToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripMenuItem wytnijToolStripMenuItem;
        private ToolStripMenuItem copyToolStripMenuItem;
        private ToolStripMenuItem pasteToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripMenuItem wybierzwszystkoToolStripMenuItem;
        private ToolStripMenuItem narzędziaToolStripMenuItem;
        private ToolStripMenuItem customizeToolStripMenuItem;
        private ToolStripMenuItem optionsToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem zawartośćToolStripMenuItem;
        private ToolStripMenuItem indexToolStripMenuItem;
        private ToolStripMenuItem wyszukajToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator5;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private ToolStripMenuItem pobiezzdiecieToolStripMenuItem;
        private Label label3;
        private Label label2;
        private RadioButton rB_przyciemnienie;
        private RadioButton rB_rozjasnienie;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private ToolStripMenuItem pobieiezToolStripMenuItem;
        private ToolStripMenuItem pobieiez2ToolStripMenuItem;
        private Button btnWybierzObraz2;
        private PictureBox pictureBox2;
        private RadioButton rB_Roznica;
        private RadioButton rB_Suma;
        private PictureBox pictureBox3;
        private RadioButton rB_Rozcienczenie;
        private RadioButton rB_Reflect_mode;
        private RadioButton rB_Ostre_swiatło;
        private RadioButton rB_Wylaczenie;
        private RadioButton rB_Ciemniejsze;
        private RadioButton cB_Mnozenie_odwrotności;
        private RadioButton rB_Wypalanie;
        private RadioButton rB_Przezroczystosc;
        private RadioButton cB_lagodne_swiatlo;
        private RadioButton rB_Nakladka;
        private RadioButton rB_Jaśniejsze;
        private RadioButton rB_Negacja;
        private RadioButton eB_Mnozenie;
        private RadioButton rB_Odejmowanie;
        private Panel panel1;
        private Label label4;
        private Label l_wattoc_pissil;
        private Button button1;
        private Label l_wattoc_pissil2;
        private Label label6;
        private TrackBar trackBar2;
    }
}
